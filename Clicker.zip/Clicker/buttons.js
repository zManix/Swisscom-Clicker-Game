const button = document.getElementById("myButton");
button.addEventListener("click", function(spa) {
  // Change the background image
  button.style.backgroundImage = "url('/Images/SwisscomLogo.png')";
  
  // OR replace the button content with an image
  button.innerHTML = "<img src='/Images/SwisscomLogo.png' alt='/Images/SwisscomLogo.png'>";
});